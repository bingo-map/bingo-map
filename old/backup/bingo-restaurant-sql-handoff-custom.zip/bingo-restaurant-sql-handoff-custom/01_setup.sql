﻿-- BinGo Map / RESTAURANT 준비 파일
-- 사용자가 제공한 TB_RESTAURANTS.sql의 구조를 기준으로 만든 비파괴형 준비 파일입니다.
-- 기존 식당 행/ID/공개값을 삭제하지 않습니다.
-- SQL Developer에서 파일 전체 F5로 실행하세요.
-- DDL은 Oracle 특성상 자동 커밋될 수 있습니다.
SET SERVEROUTPUT ON
SET DEFINE OFF
SET VERIFY OFF

PROMPT ===== CONNECTION =====
SELECT USER AS CONNECTED_USER,
       SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') AS CURRENT_SCHEMA,
       SYS_CONTEXT('USERENV', 'DB_NAME') AS DB_NAME
FROM DUAL;

DECLARE
    v_exists NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_exists
    FROM USER_TABLES
    WHERE TABLE_NAME = 'RESTAURANT';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE q'[
            CREATE TABLE RESTAURANT (
                RESTAURANT_ID      NUMBER(19) PRIMARY KEY,
                NAME               VARCHAR2(100) NOT NULL,
                CATEGORY           VARCHAR2(50),
                TAGS               VARCHAR2(200),
                RATING             NUMBER(3,1),
                REVIEW_COUNT       NUMBER(10),
                DESCRIPTION        VARCHAR2(1000),
                ADDRESS            VARCHAR2(300),
                LATITUDE           NUMBER(10,7),
                LONGITUDE          NUMBER(10,7),
                OPENING_HOURS      VARCHAR2(100),
                PHONE              VARCHAR2(50),
                PRICE_RANGE        VARCHAR2(50),
                WEBSITE_URL        VARCHAR2(300),
                SEAT_INFO          VARCHAR2(100),
                RESERVATION_INFO   VARCHAR2(100),
                PAYMENT_METHODS    VARCHAR2(200),
                LANGUAGES          VARCHAR2(200),
                MAIN_IMAGE_URL     VARCHAR2(500),
                MENU_NAME          VARCHAR2(100),
                MENU_DESCRIPTION   VARCHAR2(500),
                MENU_PRICE         VARCHAR2(50),
                MENU_IMAGE_URL     VARCHAR2(500),
                IS_PUBLISHED       CHAR(1) DEFAULT 'N' NOT NULL,
                CREATED_AT         TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL,
                UPDATED_AT         TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL,
                CONSTRAINT CK_RESTAURANT_IS_PUBLISHED CHECK (IS_PUBLISHED IN ('Y','N'))
            )
        ]';
        DBMS_OUTPUT.PUT_LINE('CREATED: RESTAURANT');
    ELSE
        DBMS_OUTPUT.PUT_LINE('EXISTS: RESTAURANT - existing rows are preserved');
    END IF;

    SELECT COUNT(*) INTO v_exists
    FROM USER_SEQUENCES
    WHERE SEQUENCE_NAME = 'SEQ_RESTAURANT';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE q'[
            CREATE SEQUENCE SEQ_RESTAURANT
                START WITH 1
                INCREMENT BY 1
                NOCACHE
                NOCYCLE
        ]';
        DBMS_OUTPUT.PUT_LINE('CREATED: SEQ_RESTAURANT');
    ELSE
        DBMS_OUTPUT.PUT_LINE('EXISTS: SEQ_RESTAURANT - not reset');
    END IF;
END;
/

DECLARE
    v_exists NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_exists
    FROM USER_TAB_COLUMNS
    WHERE TABLE_NAME = 'RESTAURANT'
      AND COLUMN_NAME = 'IS_PUBLISHED';

    IF v_exists = 0 THEN
        EXECUTE IMMEDIATE
            'ALTER TABLE RESTAURANT ADD (IS_PUBLISHED CHAR(1) DEFAULT ''N'' NOT NULL)';
        EXECUTE IMMEDIATE
            'ALTER TABLE RESTAURANT ADD CONSTRAINT CK_RESTAURANT_IS_PUBLISHED CHECK (IS_PUBLISHED IN (''Y'',''N''))';
        DBMS_OUTPUT.PUT_LINE('ADDED: IS_PUBLISHED');
    ELSE
        DBMS_OUTPUT.PUT_LINE('EXISTS: IS_PUBLISHED');
    END IF;
END;
/

PROMPT ===== CURRENT RESTAURANT RESULT =====
SELECT COUNT(*) AS TOTAL_ROWS,
       COUNT(CASE WHEN IS_PUBLISHED = 'Y' THEN 1 END) AS PUBLIC_ROWS,
       COUNT(CASE WHEN IS_PUBLISHED = 'N' THEN 1 END) AS PRIVATE_ROWS
FROM RESTAURANT;

PROMPT ===== SETUP_OK =====
SET VERIFY ON
