﻿# BinGo Map 식당 DB — 사용자 TB 데이터 반영용 SQL 묶음

사용자가 제공한 `TB_RESTAURANTS.sql`의 **49개 식당 데이터**를 기준으로, 기존에 제공된 `bingo-restaurant-sql-handoff` 형식에 맞춰 정리한 버전입니다.

## 파일 구성

| 파일 | 역할 | 데이터 변경 |
|---|---|---|
| `01_setup.sql` | RESTAURANT/시퀀스 준비 및 공개 컬럼 확인 | 기존 행/ID 삭제 안 함 |
| `02_publication.sql` | 공개 예정 목록 확인 및 Y/N 적용 | PREVIEW는 조회만, APPLY는 Y/N 변경 |
| `03_seed_restaurants.sql` | 사용자가 만든 49개 TB 데이터 추가 | 같은 이름+주소가 있으면 건너뜀 |
| `README.md` | 실행 순서와 식당 수정 방법 | 설명 |

## 권장 실행 순서

### 1. 앱 중지

Spring Boot 앱과 식당 Loader가 DB를 수정하지 않도록 잠시 중지합니다.

### 2. `01_setup.sql`

SQL Developer에서 파일 전체를 **F5**로 실행합니다.

확인할 것:

```text
SETUP_OK
```

기존 RESTAURANT 행이 있으면 삭제하지 않습니다.

### 3. `03_seed_restaurants.sql`

사용자가 제공한 TB 데이터 49개를 반영합니다.

- 기존 데이터를 DROP하지 않습니다.
- `NAME + ADDRESS`가 같은 행은 다시 넣지 않습니다.
- 새 데이터만 `SEQ_RESTAURANT.NEXTVAL`로 추가합니다.
- 실행 후 결과를 확인하고 `COMMIT;` 또는 `ROLLBACK;`을 선택합니다.

### 4. `02_publication.sql`

처음에는 반드시:

```sql
DEFINE BINGO_RESTAURANT_MODE = PREVIEW
```

상태로 전체 F5 실행합니다.

공개 예정 목록과 `PLANNED_PUBLIC`, `TO_PUBLISH`, `TO_HIDE`를 확인합니다.

적용할 때만 원래 한 줄을:

```sql
DEFINE BINGO_RESTAURANT_MODE = APPLY
```

로 바꾸고 **파일 전체 F5**를 다시 실행합니다.

결과가 맞으면 같은 접속에서:

```sql
COMMIT;
```

잘못됐으면 COMMIT 전에:

```sql
ROLLBACK;
```

합니다.

적용 후에는 파일을 다시 `PREVIEW`로 저장해 두는 것을 권장합니다.

---

## 식당 검색

식당 ID를 찾을 때:

```sql
SELECT RESTAURANT_ID, NAME, ADDRESS, IS_PUBLISHED
FROM RESTAURANT
WHERE UPPER(NAME) LIKE '%식당이름%'
ORDER BY RESTAURANT_ID;
```

예:

```sql
WHERE UPPER(NAME) LIKE '%쿠쿠루%'
```

`%`를 앞뒤에 넣으면 이름에 해당 문자열이 포함된 식당을 찾습니다.

---

## 식당 정보 수정

먼저 실제 ID를 확인한 뒤 수정합니다.

```sql
UPDATE RESTAURANT
SET
    DESCRIPTION      = '확인한 식당 소개',
    ADDRESS          = '확인한 실제 주소',
    OPENING_HOURS    = '11:00 - 21:00',
    PRICE_RANGE      = '500~1,000엔',
    MENU_NAME        = '타코야키 8개',
    MENU_DESCRIPTION = '확인한 대표 메뉴 설명',
    MENU_PRICE       = '800엔',
    MAIN_IMAGE_URL   = '/images/restaurants/shop-123-main.jpg',
    UPDATED_AT       = SYSTIMESTAMP
WHERE RESTAURANT_ID = 123;
```

`123`은 실제 식당 ID로 바꿉니다.

수정 후:

```sql
SELECT RESTAURANT_ID, NAME, DESCRIPTION,
       ADDRESS, OPENING_HOURS,
       MENU_NAME, MENU_PRICE, MAIN_IMAGE_URL,
       IS_PUBLISHED
FROM RESTAURANT
WHERE RESTAURANT_ID = 123;
```

결과를 확인합니다.

확인 후:

```sql
COMMIT;
```

취소하려면 COMMIT 전에:

```sql
ROLLBACK;
```

---

## 직접 공개/비공개

특정 식당 하나만 직접 공개하려면:

```sql
UPDATE RESTAURANT
SET IS_PUBLISHED = 'Y',
    UPDATED_AT = SYSTIMESTAMP
WHERE RESTAURANT_ID = 123;
```

비공개는:

```sql
UPDATE RESTAURANT
SET IS_PUBLISHED = 'N',
    UPDATED_AT = SYSTIMESTAMP
WHERE RESTAURANT_ID = 123;
```

확인 후 `COMMIT;`합니다.

단, `02_publication.sql`을 다시 APPLY하면 해당 공개 선별 기준에 따라 Y/N이 다시 평가될 수 있습니다.

---

## 대표 사진

DB에는 PC 경로가 아니라 웹 경로를 저장합니다.

예:

```text
/images/restaurants/shop-main.jpg
```

프로젝트에서는:

```text
src/main/resources/static/images/restaurants/shop-main.jpg
```

에 파일을 둡니다.

브라우저에서:

```text
http://localhost:8080/images/restaurants/shop-main.jpg
```

로 직접 열리는지 확인합니다.

---

## 사용자가 제공한 TB 데이터에 대한 주의

원본 `TB_RESTAURANTS.sql`은 처음에:

```sql
DROP TABLE RESTAURANT CASCADE CONSTRAINTS;
DROP SEQUENCE SEQ_RESTAURANT;
```

를 실행합니다.

**이 묶음에서는 그 방식을 사용하지 않습니다.**

기존 DB가 있는 상태에서 원본 TB 파일을 그대로 실행하면 기존 식당 데이터가 삭제될 수 있으므로, 이 ZIP에서는 `03_seed_restaurants.sql`로 안전하게 추가하도록 분리했습니다.

또한 원본 TB 데이터의 49개 식당은 현재 데이터 자체를 기준으로 사용했으며, 이 묶음에서 식당의 실제 영업 여부·가격·주소·사진의 진위를 별도로 검증하지 않았습니다.

## 공개 기준

`02_publication.sql`은 다음 기준을 사용합니다.

- 기본정보형: 이름 + 좌표 범위 + 주소 + 영업시간
- 상세정보형: 기본정보 + 분류 + 소개 + 메뉴명 + 숫자가 포함된 메뉴가격 + 대표사진 또는 메뉴사진
- 상세정보형을 우선 공개
- 부족하면 기본정보형을 추가해 최대 50곳까지 계획
- 전화/웹사이트/분류/소개/메뉴/가격/사진 정보가 많을수록 추가 점수가 높음
- 동점은 `RESTAURANT_ID` 순서

좌표 범위:

```text
위도 34.55 ~ 34.82
경도 135.35 ~ 135.65
```

이는 정확한 행정구역 경계가 아니라 후보 범위를 제한하기 위한 값입니다.

## 현재 TB 데이터

총 49개 식당을 `03_seed_restaurants.sql`에 포함했습니다.

데이터 예:

- 타코야끼 쿠쿠루 본점
- 호젠지 산페이
- 오코노미야끼 치보 도톤보리빌딩점
- 나루토 타이야키 본점 센니치마에 아이조바시점
- 호타루(쿠시카츠)
- 오뎅야
- 아카오니 도톤보리점
- 코가류 도톤보리점
- 미즈노 도톤보리 본점
- 킨류 라멘 도톤보리 본점
- 이치란 라멘 도톤보리점
- 카니도라쿠 도톤보리 본점
- 다이키 수산 회전초밥 도톤보리점
- 규카츠 모토무라 난바점
- 하나다코
- 신세카이 칸칸
- 쿠라스시 신세카이 츠텐카쿠점
- 코메다커피 KITTE오사카점
- 하브스 테이크아웃숍 다이마루 우메다점

등 총 49개입니다.
